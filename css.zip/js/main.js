/* =========================================
   ACADEMIX PRO – MAIN JAVASCRIPT
   ========================================= */

(function () {
  "use strict";

  /* ===== NAVBAR SCROLL ===== */
  const navbar = document.getElementById("navbar");
  window.addEventListener("scroll", function () {
    if (window.scrollY > 60) {
      navbar.classList.add("scrolled");
    } else {
      navbar.classList.remove("scrolled");
    }
  });

  /* ===== HAMBURGER MENU ===== */
  const hamburger = document.getElementById("hamburger");
  const navLinks = document.getElementById("navLinks");
  const navCta = document.querySelector(".nav-cta");

  if (hamburger && navLinks) {
    hamburger.addEventListener("click", function () {
      const isOpen = navLinks.classList.toggle("open");
      hamburger.classList.toggle("active", isOpen);

      // Inject a CTA button inside mobile menu if not already there
      if (isOpen) {
        if (!navLinks.querySelector(".mobile-cta")) {
          const mCta = document.createElement("li");
          mCta.innerHTML = '<a href="#contact" class="btn-primary mobile-cta" style="margin:10px 0 0;justify-content:center;display:flex;"><i class="fas fa-calendar-check"></i> Free Consultation</a>';
          navLinks.appendChild(mCta);
        }
      }
    });

    // Close on link click
    navLinks.addEventListener("click", function (e) {
      if (e.target.closest("a")) {
        hamburger.classList.remove("active");
        navLinks.classList.remove("open");
      }
    });

    // Close on outside click
    document.addEventListener("click", function (e) {
      if (!navbar.contains(e.target)) {
        hamburger.classList.remove("active");
        navLinks.classList.remove("open");
      }
    });
  }

  /* ===== SMOOTH SCROLL ===== */
  document.querySelectorAll('a[href^="#"]').forEach((anchor) => {
    anchor.addEventListener("click", function (e) {
      const target = document.querySelector(this.getAttribute("href"));
      if (target) {
        e.preventDefault();
        const offset = navbar ? navbar.offsetHeight + 10 : 80;
        window.scrollTo({
          top: target.offsetTop - offset,
          behavior: "smooth",
        });
      }
    });
  });

  /* ===== ACTIVE NAV LINK ===== */
  const sections = document.querySelectorAll("section[id], div[id]");
  const navItems = document.querySelectorAll(".nav-links a");
  function setActiveNav() {
    let current = "";
    sections.forEach((section) => {
      if (window.scrollY >= section.offsetTop - 120) {
        current = section.getAttribute("id");
      }
    });
    navItems.forEach((link) => {
      link.classList.remove("active");
      if (link.getAttribute("href") === "#" + current) {
        link.classList.add("active");
      }
    });
  }
  window.addEventListener("scroll", setActiveNav);

  /* ===== BACK TO TOP ===== */
  const backToTop = document.getElementById("backToTop");
  if (backToTop) {
    window.addEventListener("scroll", function () {
      if (window.scrollY > 400) {
        backToTop.classList.add("visible");
      } else {
        backToTop.classList.remove("visible");
      }
    });
    backToTop.addEventListener("click", function () {
      window.scrollTo({ top: 0, behavior: "smooth" });
    });
  }

  /* ===== AOS – INTERSECTION OBSERVER ===== */
  function initAOS() {
    const elements = document.querySelectorAll("[data-aos]");
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            const delay = entry.target.dataset.aosDelay || 0;
            setTimeout(() => {
              entry.target.classList.add("aos-animate");
            }, parseInt(delay));
            observer.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.1, rootMargin: "0px 0px -60px 0px" }
    );
    elements.forEach((el) => observer.observe(el));
  }
  initAOS();

  /* ===== COUNTER ANIMATION ===== */
  function animateCounter(el, target, duration) {
    const isDecimal = target.toString().includes(".");
    const start = 0;
    const startTime = performance.now();
    function update(currentTime) {
      const elapsed = currentTime - startTime;
      const progress = Math.min(elapsed / duration, 1);
      const ease = 1 - Math.pow(1 - progress, 4);
      const value = start + (target - start) * ease;
      if (isDecimal) {
        el.textContent = value.toFixed(1);
      } else {
        el.textContent = Math.floor(value).toLocaleString();
      }
      if (progress < 1) requestAnimationFrame(update);
      else {
        // Restore suffix
        const suffix = el.dataset.suffix || "";
        if (isDecimal) {
          el.textContent = target.toFixed(1) + suffix;
        } else {
          el.textContent = Math.floor(target).toLocaleString() + suffix;
        }
      }
    }
    requestAnimationFrame(update);
  }

  function initCounters() {
    const statNums = document.querySelectorAll(".stat-num");
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            const el = entry.target;
            const raw = el.dataset.target;
            const suffix = el.textContent.replace(/[0-9.]/g, "");
            el.dataset.suffix = suffix;
            const target = parseFloat(raw);
            animateCounter(el, target, 2000);
            observer.unobserve(el);
          }
        });
      },
      { threshold: 0.5 }
    );
    statNums.forEach((el) => observer.observe(el));
  }
  initCounters();

  /* ===== HERO PARTICLES ===== */
  function createParticles() {
    const container = document.getElementById("particles");
    if (!container) return;
    const count = 20;
    for (let i = 0; i < count; i++) {
      const particle = document.createElement("div");
      particle.style.cssText = `
        position: absolute;
        width: ${Math.random() * 8 + 2}px;
        height: ${Math.random() * 8 + 2}px;
        background: rgba(230, 57, 70, ${Math.random() * 0.4 + 0.1});
        border-radius: 50%;
        top: ${Math.random() * 100}%;
        left: ${Math.random() * 100}%;
        animation: particleFloat ${Math.random() * 10 + 8}s ease-in-out infinite;
        animation-delay: ${Math.random() * 5}s;
      `;
      container.appendChild(particle);
    }

    // Add particle keyframe if not existing
    if (!document.getElementById("particle-style")) {
      const style = document.createElement("style");
      style.id = "particle-style";
      style.textContent = `
        @keyframes particleFloat {
          0%, 100% { transform: translateY(0) translateX(0) scale(1); opacity: 0.3; }
          25% { transform: translateY(-30px) translateX(15px) scale(1.2); opacity: 0.6; }
          50% { transform: translateY(-15px) translateX(-20px) scale(0.8); opacity: 0.4; }
          75% { transform: translateY(-40px) translateX(10px) scale(1.1); opacity: 0.5; }
        }
      `;
      document.head.appendChild(style);
    }
  }
  createParticles();

  /* ===== TESTIMONIAL SLIDER ===== */
  let testiSliderInstance = null;

  function initTestimonialSlider() {
    const cards = Array.from(document.querySelectorAll(".testi-card"));
    const dotsContainer = document.getElementById("testiDots");
    const prevBtn = document.getElementById("testiPrev");
    const nextBtn = document.getElementById("testiNext");
    if (!cards.length || !dotsContainer) return;

    // Clear previous auto-slide
    if (testiSliderInstance) clearInterval(testiSliderInstance);

    const w = window.innerWidth;
    const perPage = w >= 900 ? 3 : w >= 600 ? 2 : 1;
    const totalPages = Math.ceil(cards.length / perPage);
    let currentPage = 0;

    // Reset all cards to default display
    cards.forEach(c => { c.style.display = ""; });

    // Create dots
    dotsContainer.innerHTML = "";
    for (let i = 0; i < totalPages; i++) {
      const dot = document.createElement("div");
      dot.className = "testi-dot" + (i === 0 ? " active" : "");
      dot.addEventListener("click", () => goToPage(i));
      dotsContainer.appendChild(dot);
    }

    function showPage(page) {
      const start = page * perPage;
      const end = start + perPage;
      cards.forEach((card, index) => {
        if (index >= start && index < end) {
          card.style.display = "block";
          card.style.animation = "fadeInUp 0.4s ease forwards";
        } else {
          card.style.display = "none";
        }
      });
      document.querySelectorAll(".testi-dot").forEach((dot, i) => {
        dot.classList.toggle("active", i === page);
      });
      currentPage = page;
    }

    function goToPage(page) {
      currentPage = ((page % totalPages) + totalPages) % totalPages;
      showPage(currentPage);
      resetAuto();
    }

    function resetAuto() {
      clearInterval(testiSliderInstance);
      testiSliderInstance = setInterval(() => goToPage(currentPage + 1), 5000);
    }

    // Re-attach button listeners (remove old first)
    const newPrev = prevBtn.cloneNode(true);
    const newNext = nextBtn.cloneNode(true);
    prevBtn.parentNode.replaceChild(newPrev, prevBtn);
    nextBtn.parentNode.replaceChild(newNext, nextBtn);
    newPrev.addEventListener("click", () => goToPage(currentPage - 1));
    newNext.addEventListener("click", () => goToPage(currentPage + 1));

    showPage(0);
    resetAuto();
  }

  initTestimonialSlider();

  // Debounced resize
  let resizeTimer;
  window.addEventListener("resize", () => {
    clearTimeout(resizeTimer);
    resizeTimer = setTimeout(initTestimonialSlider, 250);
  });

  /* ===== VIDEO AUTOPLAY FALLBACK ===== */
  window.addEventListener("load", function () {
    var videos = document.querySelectorAll(".hero-video, .cta-video");
    videos.forEach(function(vid) {
      vid.muted = true;
      var p = vid.play();
      if (p !== undefined) {
        p.catch(function () {
          document.addEventListener("click", function onFirst() {
            vid.play();
            document.removeEventListener("click", onFirst);
          }, { once: true });
        });
      }
    });
  });

  /* ===== NEWSLETTER FORM ===== */
  const newsletterForm = document.querySelector(".newsletter-form");
  if (newsletterForm) {
    newsletterForm.addEventListener("submit", function (e) {
      e.preventDefault();
      const input = this.querySelector("input");
      if (input && input.value) {
        const btn = this.querySelector("button");
        btn.innerHTML = '<i class="fas fa-check"></i>';
        btn.style.background = "#28a745";
        input.value = "";
        setTimeout(() => {
          btn.innerHTML = '<i class="fas fa-paper-plane"></i>';
          btn.style.background = "";
        }, 3000);
      }
    });
  }

  /* ===== TEAM MODAL ===== */
  const openTeamBtn = document.getElementById("openTeamModal");
  const closeTeamBtn = document.getElementById("closeTeamModal");
  const teamModal = document.getElementById("teamModal");
  const navTeamLink = document.getElementById("navTeamLink");

  function openModal() {
    teamModal.style.display = "block";
    document.body.style.overflow = "hidden";
  }
  function closeModal() {
    teamModal.style.display = "none";
    document.body.style.overflow = "";
  }

  if (navTeamLink && teamModal) {
    navTeamLink.addEventListener("click", function (e) {
      e.preventDefault();
      // Close mobile menu if open
      const navLinks = document.getElementById("navLinks");
      const hamburger = document.getElementById("hamburger");
      if (navLinks) navLinks.classList.remove("open");
      if (hamburger) hamburger.classList.remove("active");
      openModal();
    });
  }
  if (openTeamBtn && teamModal) {
    openTeamBtn.addEventListener("click", openModal);
  }
  if (closeTeamBtn && teamModal) {
    closeTeamBtn.addEventListener("click", closeModal);
  }
  if (teamModal) {
    teamModal.addEventListener("click", function (e) {
      if (e.target === teamModal) closeModal();
    });
    document.addEventListener("keydown", function (e) {
      if (e.key === "Escape" && teamModal.style.display === "block") closeModal();
    });
  }

  /* ===== FORM VALIDATION FEEDBACK ===== */
  const contactForm = document.querySelector(".contact-form");
  if (contactForm) {
    contactForm.querySelectorAll("input, select, textarea").forEach((field) => {
      field.addEventListener("blur", function () {
        if (this.required && !this.value.trim()) {
          this.style.borderColor = "#e63946";
        } else {
          this.style.borderColor = "";
        }
      });
      field.addEventListener("focus", function () {
        this.style.borderColor = "";
      });
    });
  }

  /* ===== SCROLL REVEAL FOR NAVBAR ===== */
  let lastScroll = 0;
  window.addEventListener("scroll", function () {
    const current = window.scrollY;
    if (current > lastScroll && current > 200) {
      navbar.style.transform = "translateY(-100%)";
    } else {
      navbar.style.transform = "translateY(0)";
    }
    lastScroll = current;
  });

  // Fix navbar transition
  if (navbar) {
    navbar.style.transition = "transform 0.3s ease, padding 0.3s ease, box-shadow 0.3s ease";
  }

})();
