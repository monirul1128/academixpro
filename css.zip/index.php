<?php
$page_title = "Academix Pro – Dream Abroad | Proficiency Support | 96.5% Visa Success";
$site_name = "Academix Pro";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?></title>
    <meta name="description" content="Academix Pro – Your trusted partner for overseas education. Proficiency support, admission process guidance, and 96.5% visa success ratio.">
    <link rel="stylesheet" href="css/style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800;900&family=Playfair+Display:wght@700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body>

<!-- ===== TOPBAR ===== -->
<div class="topbar">
    <div class="container topbar-inner">
        <div class="topbar-left">
            <a href="mailto:info@academixprobd.com"><i class="fas fa-envelope"></i> info@academixprobd.com</a>
            <a href="tel:+8801612594546"><i class="fas fa-phone"></i> 01612594546</a>
        </div>
        <div class="topbar-right">
            <a href="#" aria-label="Facebook"><i class="fab fa-facebook-f"></i></a>
            <a href="https://wa.me/8801612594546" target="_blank" aria-label="WhatsApp"><i class="fab fa-whatsapp"></i></a>
        </div>
    </div>
</div>

<!-- ===== NAVBAR ===== -->
<nav class="navbar" id="navbar">
    <div class="container navbar-inner">
        <a href="index.php" class="nav-logo">
            <img src="images/logo (2).jpg" alt="Academix Pro Logo">
            <span><?php echo $site_name; ?></span>
        </a>
        <ul class="nav-links" id="navLinks">
            <li><a href="#home">Home</a></li>
            <li><a href="#services">Services</a></li>
            <li><a href="#destinations">Destinations</a></li>
            <li><a href="#about">About</a></li>
            <li><a href="#team" id="navTeamLink">Team</a></li>
            <li><a href="#testimonials">Testimonials</a></li>
            <li><a href="#contact">Contact</a></li>
        </ul>
        <a href="#contact" class="btn-primary nav-cta">Free Consultation</a>
        <button class="hamburger" id="hamburger" aria-label="Toggle menu">
            <span></span><span></span><span></span>
        </button>
    </div>
</nav>

<!-- ===== HERO SECTION ===== -->
<section class="hero" id="home">
    <!-- Background video -->
    <video class="hero-video" autoplay muted loop playsinline preload="auto" aria-hidden="true">
        <source src="video/15379855_3840_2160_30fps.mp4" type="video/mp4">
    </video>
    <div class="hero-overlay"></div>
    <div class="hero-particles" id="particles"></div>
    <div class="container hero-content">
        <div class="hero-badge"><i class="fas fa-star"></i> Trusted by 1000+ Students Across 12 Countries</div>
        <h1>
            🎓 Dream Abroad with<br>
            <span class="brand-gradient"><?php echo $site_name; ?></span>
        </h1>
        <p class="hero-subtitle">✈️ Proficiency Support &nbsp;|&nbsp; Admission Process &nbsp;|&nbsp; <strong>96.5% Visa File Success</strong></p>
        <p class="hero-desc">Your trusted gateway to world-class universities. We guide you from test preparation to landing your dream destination — stress-free, fast, and successful.</p>
        <div class="hero-btns">
            <a href="#contact" class="btn-primary btn-lg"><i class="fas fa-rocket"></i> Start Your Journey</a>
            <a href="#services" class="btn-outline btn-lg"><i class="fas fa-play-circle"></i> Explore Services</a>
        </div>
        <div class="hero-stats">
            <div class="hstat"><span class="hstat-num">1000+</span><span>Happy Students</span></div>
            <div class="hstat-div"></div>
            <div class="hstat"><span class="hstat-num">96.5%</span><span>Visa Success</span></div>
            <div class="hstat-div"></div>
            <div class="hstat"><span class="hstat-num">50+</span><span>Universities</span></div>
            <div class="hstat-div"></div>
            <div class="hstat"><span class="hstat-num">12</span><span>Countries</span></div>
        </div>
    </div>
    <div class="hero-scroll"><a href="#services"><i class="fas fa-chevron-down"></i></a></div>
</section>

<!-- ===== MARQUEE STRIP ===== -->
<div class="marquee-strip">
    <div class="marquee-track">
        <?php
        $flags = ["🇫🇮 Finland","🇨🇦 Canada","🇸🇪 Sweden","🇬🇧 UK","🇩🇰 Denmark","🇦🇺 Australia","🇫🇮 Finland","🇨🇦 Canada","🇸🇪 Sweden","🇬🇧 UK","🇩🇰 Denmark","🇦🇺 Australia"];
        $repeated = array_merge($flags, $flags);
        foreach($repeated as $flag): ?>
            <span class="marquee-item"><i class="fas fa-graduation-cap"></i> <?php echo $flag; ?></span>
        <?php endforeach; ?>
    </div>
</div>

<!-- ===== SERVICES SECTION ===== -->
<section class="section services" id="services">
    <div class="container">
        <div class="section-header">
            <span class="section-tag">What We Offer</span>
            <h2>Our <span class="text-red">Core Services</span></h2>
            <p>End-to-end support from the moment you dream to the day you depart.</p>
        </div>
        <div class="services-grid">
            <?php
            $services = [
                ["fas fa-book-open","Proficiency Support","Expert coaching for IELTS, TOEFL, PTE, Duolingo, GRE & GMAT. Our trainers ensure you hit your target score — guaranteed.","#e63946"],
                ["fas fa-university","University Admission","We handle shortlisting, SOP writing, document preparation, and application submission for top universities worldwide.","#c1121f"],
                ["fas fa-passport","Visa Processing","With a 96.5% visa success ratio, our visa experts prepare a flawless application and prepare you for every interview.","#e63946"],
                ["fas fa-plane-departure","Pre-Departure Briefing","Comprehensive orientation on accommodation, banking, culture, and everything you need before you fly.","#c1121f"],
                ["fas fa-language","English Language Courses","From beginner to advanced, our structured English programs prepare students for academic and professional environments.","#e63946"],
                ["fas fa-handshake","Career Counseling","Personalised guidance to align your academic choices with your career goals and future prospects abroad.","#c1121f"],
            ];
            foreach($services as $s): ?>
            <div class="service-card" data-aos="fade-up">
                <div class="service-icon" style="background: <?php echo $s[3]; ?>20; color: <?php echo $s[3]; ?>">
                    <i class="<?php echo $s[0]; ?>"></i>
                </div>
                <h3><?php echo $s[1]; ?></h3>
                <p><?php echo $s[2]; ?></p>
                <a href="#contact" class="service-link">Learn More <i class="fas fa-arrow-right"></i></a>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- ===== WHY CHOOSE US ===== -->
<section class="section why-us">
    <div class="container">
        <div class="why-inner">
            <div class="why-left" data-aos="fade-right">
                <span class="section-tag">Why Academix Pro?</span>
                <h2>We Make Your <span class="text-red">Dream</span> a Reality</h2>
                <p>We are not just a consultancy — we are your dedicated education partner. From the first query to the final visa stamp, we are with you at every step.</p>
                <ul class="why-list">
                    <?php
                    $whys = [
                        "96.5% Visa File Success Rate",
                        "Certified counselors with global university tie-ups",
                        "Personalised roadmap for every student",
                        "Fastest processing & transparent process",
                        "Free IELTS mock tests & workshops",
                        "Post-arrival support network worldwide",
                    ];
                    foreach($whys as $w): ?>
                    <li><i class="fas fa-check-circle"></i> <?php echo $w; ?></li>
                    <?php endforeach; ?>
                </ul>
                <a href="#contact" class="btn-primary">Get Free Counseling</a>
            </div>
            <div class="why-right" data-aos="fade-left">
                <div class="why-card-grid">
                    <?php
                    $cards = [
                        ["fas fa-trophy","#e63946","1000+","Students Placed"],
                        ["fas fa-star","#c1121f","4.9/5","Google Rating"],
                        ["fas fa-clock","#e63946","24hrs","Response Time"],
                        ["fas fa-globe","#c1121f","12","Countries"],
                    ];
                    foreach($cards as $c): ?>
                    <div class="why-card">
                        <i class="<?php echo $c[0]; ?>" style="color:<?php echo $c[1]; ?>"></i>
                        <strong><?php echo $c[2]; ?></strong>
                        <span><?php echo $c[3]; ?></span>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- ===== DESTINATIONS SECTION ===== -->
<section class="section destinations" id="destinations">
    <div class="container">
        <div class="section-header">
            <span class="section-tag">Study Destinations</span>
            <h2>Top <span class="text-red">Countries</span> We Cover</h2>
            <p>Unlock opportunities in the world's most prestigious education destinations.</p>
        </div>
        <div class="dest-grid">
            <?php
            $destinations = [
                ["🇫🇮","Finland","World-class education, research excellence.","University of Helsinki, Aalto, Tampere"],
                ["🇨🇦","Canada","Quality education + PR pathway.","UofT, UBC, McGill"],
                ["🇸🇪","Sweden","Innovation-driven, globally respected degrees.","Uppsala, Lund, KTH"],
                ["🇬🇧","United Kingdom","Ancient traditions, modern excellence.","Oxford, Cambridge, UCL"],
                ["🇩🇰","Denmark","Free tuition, high quality of life.","Copenhagen, DTU, Aarhus"],
                ["🇦🇺","Australia","Work while you study, stay after you graduate.","ANU, UNSW, Monash"],
            ];
            foreach($destinations as $d): ?>
            <div class="dest-card" data-aos="zoom-in">
                <div class="dest-flag"><?php echo $d[0]; ?></div>
                <h3><?php echo $d[1]; ?></h3>
                <p><?php echo $d[2]; ?></p>
                <div class="dest-unis"><i class="fas fa-graduation-cap"></i> <?php echo $d[3]; ?></div>
                <a href="#contact" class="dest-btn">Apply Now</a>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- ===== PROCESS SECTION ===== -->
<section class="section process">
    <div class="container">
        <div class="section-header">
            <span class="section-tag">How It Works</span>
            <h2>Your <span class="text-red">Journey</span> in 5 Simple Steps</h2>
        </div>
        <div class="process-steps">
            <?php
            $steps = [
                ["01","fas fa-comments","Free Consultation","Book a free session with our experts and discuss your goals, budget, and preferences."],
                ["02","fas fa-clipboard-list","Profile Assessment","We evaluate your academic background, test scores, and career objectives."],
                ["03","fas fa-university","University Selection","We shortlist the best-fit universities and programs tailored to your profile."],
                ["04","fas fa-file-alt","Application & Docs","Our team prepares your SOP, LOR, and complete application package."],
                ["05","fas fa-passport","Visa & Departure","We process your visa with 96.5% success rate and prepare you for departure."],
            ];
            foreach($steps as $i => $step): ?>
            <div class="step" data-aos="fade-up" data-aos-delay="<?php echo $i * 100; ?>">
                <div class="step-num"><?php echo $step[0]; ?></div>
                <div class="step-icon"><i class="<?php echo $step[1]; ?>"></i></div>
                <div class="step-content">
                    <h4><?php echo $step[2]; ?></h4>
                    <p><?php echo $step[3]; ?></p>
                </div>
                <?php if($i < count($steps)-1): ?><div class="step-arrow"><i class="fas fa-chevron-right"></i></div><?php endif; ?>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- ===== ABOUT SECTION ===== -->
<section class="section about" id="about">
    <div class="container about-inner">
        <div class="about-img-wrap" data-aos="fade-right">
            <div class="about-img-main">
                <img src="images/CEO.jpg" alt="CEO Academix Pro">
            </div>
            <div class="about-badge-float">
                <i class="fas fa-award"></i>
                <div><strong>10+ Years</strong><span>of Excellence</span></div>
            </div>
        </div>
        <div class="about-text" data-aos="fade-left">
            <span class="section-tag">ZAKARIA-AL-MAINUDDIN</span>
            <h2>Your Trusted Partner for <span class="text-red">Global Education</span></h2>
            <p>At <strong>Academix Pro</strong>, we believe every student deserves access to world-class education regardless of their background. Founded with a mission to simplify the overseas education journey, we have helped over 1,000 students secure admissions in top universities across 12 countries.</p>
            <p>Our team of certified education counselors, visa experts, and English language trainers work together to provide you with a 360° support system — from your first IELTS class to the day you step into your dream university.</p>
            <div class="about-highlights">
                <div class="ah-item"><i class="fas fa-check"></i> Authorized by leading universities</div>
                <div class="ah-item"><i class="fas fa-check"></i> British Council affiliated English programs</div>
                <div class="ah-item"><i class="fas fa-check"></i> 100% transparent fee structure</div>
                <div class="ah-item"><i class="fas fa-check"></i> Dedicated post-visa support</div>
            </div>
            <a href="#contact" class="btn-primary">Know More About Us</a>
        </div>
    </div>
</section>

<!-- ===== STATS COUNTER ===== -->
<section class="stats-section">
    <div class="container stats-grid">
        <?php
        $stats = [
            ["fas fa-user-graduate","1000+","Students Placed"],
            ["fas fa-flag","12","Countries Covered"],
            ["fas fa-university","50+","Partner Universities"],
            ["fas fa-id-card","96.5%","Visa Success Rate"],
            ["fas fa-medal","10+","Years Experience"],
            ["fas fa-star","4.9","Average Rating"],
        ];
        foreach($stats as $stat): ?>
        <div class="stat-item" data-aos="fade-up">
            <i class="<?php echo $stat[0]; ?>"></i>
            <span class="stat-num" data-target="<?php echo preg_replace('/[^0-9.]/','',$stat[1]); ?>"><?php echo $stat[1]; ?></span>
            <span class="stat-label"><?php echo $stat[2]; ?></span>
        </div>
        <?php endforeach; ?>
    </div>
</section>

<!-- ===== TEAM SECTION ===== -->
<section class="section team" id="team">
    <div class="container">
        <div class="section-header">
            <span class="section-tag">Our Team</span>
            <h2>Meet Our <span class="text-red">Expert</span> Team</h2>
            <p>Dedicated professionals committed to making your overseas education dream a success.</p>
        </div>

        <!-- CEO featured card only on main page -->
        <div class="team-ceo-wrap" style="display:flex;justify-content:center;margin-bottom:36px;">
            <div class="team-card" style="max-width:300px;" data-aos="zoom-in">
                <div class="team-img-wrap">
                    <img src="images/CEO.jpg" alt="Zakaria Al-Mainuddin">
                    <div class="team-overlay">
                        <div class="team-socials">
                            <a href="#" aria-label="LinkedIn"><i class="fas fa-linkedin-in"></i></a>
                            <a href="#" aria-label="Email"><i class="fas fa-envelope"></i></a>
                        </div>
                    </div>
                </div>
                <div class="team-info">
                    <h4>ZAKARIA-AL-MAINUDDIN</h4>
                    <span>Chief Executive Officer</span>
                    <p>Leading Academix Pro with a vision to make world-class education accessible to every student.</p>
                </div>
            </div>
        </div>

        <!-- Meet Full Team button -->
        <div style="text-align:center;">
            <button class="btn-primary" id="openTeamModal" style="min-width:220px;">
                <i class="fas fa-users"></i> Meet Full Team
            </button>
        </div>
    </div>
</section>

<!-- ===== FULL TEAM MODAL ===== -->
<div id="teamModal" style="display:none;position:fixed;inset:0;z-index:5000;background:rgba(10,10,20,0.85);overflow-y:auto;padding:40px 16px;">
    <div style="max-width:1100px;margin:0 auto;position:relative;">
        <button id="closeTeamModal" aria-label="Close team" style="position:sticky;top:0;float:right;width:44px;height:44px;background:var(--red);border:none;border-radius:50%;color:#fff;font-size:1.1rem;cursor:pointer;z-index:10;display:flex;align-items:center;justify-content:center;box-shadow:0 4px 16px rgba(0,0,0,0.3);">
            <i class="fas fa-times"></i>
        </button>
        <div style="clear:both;padding-top:8px;">
            <h2 style="text-align:center;font-family:var(--font-heading);color:#fff;margin-bottom:8px;">Our <span style="color:var(--red)">Expert</span> Team</h2>
            <p style="text-align:center;color:rgba(255,255,255,0.65);margin-bottom:36px;">The people behind your success</p>
            <div class="team-grid">
                <?php
                $fullTeam = [
                    ["images/CEO.jpg","ZAKARIA-AL-MAINUDDIN","Chief Executive Officer","Leading Academix Pro with a vision to make world-class education accessible to every student."],
                    ["images/Administrative Officer.jpg","Ali Hossain","Administrative Officer","Ensuring seamless operations and a smooth experience for every student at Academix Pro."],
                    ["images/IT Manager.jpg","Zihad Hossain","IT Manager","Powering our digital platforms to deliver the best online experience for students and staff."],
                    ["images/Student Councilor.jpg","Sajid Islam","Student Counselor","Guiding students with personalised advice to choose the right university and program."],
                    ["images/English Instructor.jpg","English Instructor","Lead Language Trainer","Helping students achieve their target IELTS/TOEFL scores with proven teaching methods."],
                    ["images/admin manager.jpeg","Admin Manager","Operations Manager","Coordinating day-to-day office activities and ensuring efficient administrative workflow."],
                    ["images/senior councillor.jpeg","Senior Councillor","Senior Education Counselor","Providing expert guidance to students on advanced academic pathways and visa strategies."],
                ];
                foreach($fullTeam as $i => $member): ?>
                <div class="team-card" data-aos="fade-up" data-aos-delay="<?php echo $i * 80; ?>">
                    <div class="team-img-wrap">
                        <img src="<?php echo $member[0]; ?>" alt="<?php echo $member[1]; ?>">
                        <div class="team-overlay">
                            <div class="team-socials">
                                <a href="#" aria-label="LinkedIn"><i class="fas fa-linkedin-in"></i></a>
                                <a href="#" aria-label="Email"><i class="fas fa-envelope"></i></a>
                            </div>
                        </div>
                    </div>
                    <div class="team-info">
                        <h4><?php echo $member[1]; ?></h4>
                        <span><?php echo $member[2]; ?></span>
                        <p><?php echo $member[3]; ?></p>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</div>

<!-- ===== TESTIMONIALS ===== -->
<section class="section testimonials" id="testimonials">
    <div class="container">
        <div class="section-header">
            <span class="section-tag">Student Stories</span>
            <h2>What Our <span class="text-red">Students</span> Say</h2>
            <p>Real stories from real Bangladeshi students who trusted Academix Pro.</p>
        </div>
        <div class="testi-slider" id="testiSlider">
            <?php
            $testimonials = [
                [
                    "Fahad",
                    "Finland – University of Helsinki",
                    "🇫🇮",
                    "Academix Pro amar jibon bodle diyeche. Finland-e asha amaar shopno chilo, kintu process ta khub complicated lagchilo. Unara shob kichhu handle korechen — IELTS preparation theke visa file porjonto. Alhamdulillah, amar visa approve hoyeche! Jara Finland or Scandinavia te jete chan, nishshongkoche Academix Pro-te jogen.",
                    "5",
                    "Dhaka, Bangladesh"
                ],
                [
                    "Ali Hossain",
                    "Canada – University of Toronto",
                    "🇨🇦",
                    "Ami age duita agency te giyechilam, keu proper guidance dite pareni. Academix Pro-te ashar por shob clear hoye gelo. Counselor bhai amake step by step bujhiyechen, documents theke SOP porjonto nijer moto kore ready kore diyechen. Canada-te ekhon ami nijei believe korte parchina! Onek onek dhonnobad Academix Pro team-ke.",
                    "5",
                    "Chittagong, Bangladesh"
                ],
                [
                    "Zihad Hossain",
                    "Sweden – Uppsala University",
                    "🇸🇪",
                    "Sweden-e scholarship niye asha amaar sapner cheye beshi chilo. Academix Pro na thakle hoyto possible hoto na. Unara amar profile analyze kore best university suggest korechen ar application process ta ekdum smooth kore diyechen. Visa interview-er jonno o alag kore prepare koriyechen. Real professional team — highly recommended!",
                    "5",
                    "Sylhet, Bangladesh"
                ],
                [
                    "Sajid Islam",
                    "UK – University of Manchester",
                    "🇬🇧",
                    "UK-te asha amar onek puranor iccha chilo. Academix Pro-er team amar shopno pura kore diyeche. IELTS-e target score pawa theke UK visa porjonto — shob jaygay unara pashe chilen. Office-e gele always welcome feel hoy, kono question thakle immediately reply koren. Trust korte paren, ei team-ke. 100% satisfied!",
                    "5",
                    "Rajshahi, Bangladesh"
                ],
            ];
            foreach($testimonials as $idx => $t): ?>
            <div class="testi-card">
                <div class="testi-quote"><i class="fas fa-quote-left"></i></div>
                <div class="testi-flag-dest" style="display:flex;align-items:center;gap:8px;margin-bottom:14px;">
                    <span style="font-size:1.6rem;line-height:1;"><?php echo $t[2]; ?></span>
                    <span style="font-size:0.8rem;font-weight:600;color:var(--red);"><?php echo $t[1]; ?></span>
                </div>
                <p style="font-size:0.88rem;line-height:1.75;"><?php echo $t[3]; ?></p>
                <div class="testi-stars" style="margin-top:14px;">
                    <?php for($s=0;$s<intval($t[4]);$s++): ?><i class="fas fa-star"></i><?php endfor; ?>
                </div>
                <div class="testi-author" style="margin-top:16px;">
                    <div class="testi-avatar" style="background:linear-gradient(135deg,var(--red),var(--dark-red));font-weight:800;font-size:1rem;font-style:normal;">
                        <?php echo mb_substr($t[0], 0, 1); ?>
                    </div>
                    <div>
                        <strong><?php echo $t[0]; ?></strong>
                        <span style="display:flex;align-items:center;gap:5px;"><i class="fas fa-map-marker-alt" style="color:var(--red);font-size:0.7rem;"></i> <?php echo $t[5]; ?></span>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
        <div class="testi-controls">
            <button id="testiPrev" aria-label="Previous"><i class="fas fa-chevron-left"></i></button>
            <div class="testi-dots" id="testiDots"></div>
            <button id="testiNext" aria-label="Next"><i class="fas fa-chevron-right"></i></button>
        </div>
    </div>
</section>

<!-- ===== CTA BANNER ===== -->
<section class="cta-banner" id="ctaBanner">

    <!-- Background video -->
    <video class="cta-video" autoplay muted loop playsinline preload="auto" aria-hidden="true">
        <source src="video/15379855_3840_2160_30fps.mp4" type="video/mp4">
    </video>

    <!-- Dark overlay so text stays readable -->
    <div class="cta-video-overlay"></div>

    <div class="container cta-inner">
        <div class="cta-text">
            <h2>Ready to Study Abroad? <span>Let's Make It Happen!</span></h2>
            <p>Join thousands of successful students who chose Academix Pro. Book your free consultation today.</p>
        </div>
        <div class="cta-btns">
            <a href="#contact" class="btn-white"><i class="fas fa-calendar-check"></i> Book Free Session</a>
            <a href="tel:+8801612594546" class="btn-outline-white"><i class="fas fa-phone"></i> Call Us Now</a>
        </div>
    </div>
</section>

<!-- ===== CONTACT SECTION ===== -->
<section class="section contact" id="contact">
    <div class="container">
        <div class="section-header">
            <span class="section-tag">Get In Touch</span>
            <h2>Start Your <span class="text-red">Journey</span> Today</h2>
            <p>Book a free consultation and let our experts guide you to your dream university.</p>
        </div>
        <div class="contact-inner">
            <div class="contact-info" data-aos="fade-right">
                <div class="cinfo-card">
                    <i class="fas fa-map-marker-alt"></i>
                    <div>
                        <h4>Visit Us</h4>
                        <p>152/2/A Green Road Panthapath<br>Dhaka, Bangladesh 1205</p>
                    </div>
                </div>
                <div class="cinfo-card">
                    <i class="fas fa-phone-alt"></i>
                    <div>
                        <h4>Call Us</h4>
                        <p><a href="tel:+8801612594546">01612594546</a><br><a href="tel:+8801701436662">01701436662</a></p>
                    </div>
                </div>
                <div class="cinfo-card">
                    <i class="fas fa-envelope"></i>
                    <div>
                        <h4>Email Us</h4>
                        <p><a href="mailto:info@academixprobd.com">info@academixprobd.com</a></p>
                    </div>
                </div>
                <div class="cinfo-card">
                    <i class="fas fa-clock"></i>
                    <div>
                        <h4>Office Hours</h4>
                        <p>Sat – Thu: 9:00 AM – 7:00 PM<br>Friday: Closed</p>
                    </div>
                </div>
                <div class="contact-socials">
                    <a href="#" aria-label="Facebook"><i class="fab fa-facebook-f"></i></a>
                    <a href="https://wa.me/8801612594546" target="_blank" aria-label="WhatsApp"><i class="fab fa-whatsapp"></i></a>
                </div>
            </div>
            <div class="contact-form-wrap" data-aos="fade-left">
                <?php
                $success_msg = '';
                $error_msg = '';
                if($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['contact_submit'])) {
                    $name    = htmlspecialchars(trim($_POST['name'] ?? ''));
                    $email   = htmlspecialchars(trim($_POST['email'] ?? ''));
                    $phone   = htmlspecialchars(trim($_POST['phone'] ?? ''));
                    $country = htmlspecialchars(trim($_POST['country'] ?? ''));
                    $service = htmlspecialchars(trim($_POST['service'] ?? ''));
                    $message = htmlspecialchars(trim($_POST['message'] ?? ''));

                    if($name && $email && $phone && $message) {
                        // Mail logic placeholder
                        $success_msg = "Thank you, $name! We'll contact you shortly.";
                    } else {
                        $error_msg = "Please fill in all required fields.";
                    }
                }
                ?>
                <?php if($success_msg): ?>
                    <div class="form-success"><i class="fas fa-check-circle"></i> <?php echo $success_msg; ?></div>
                <?php endif; ?>
                <?php if($error_msg): ?>
                    <div class="form-error"><i class="fas fa-exclamation-circle"></i> <?php echo $error_msg; ?></div>
                <?php endif; ?>
                <form class="contact-form" method="POST" action="#contact">
                    <div class="form-row">
                        <div class="form-group">
                            <label for="name">Full Name *</label>
                            <input type="text" id="name" name="name" placeholder="Your full name" required>
                        </div>
                        <div class="form-group">
                            <label for="email">Email Address *</label>
                            <input type="email" id="email" name="email" placeholder="your@email.com" required>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group">
                            <label for="phone">Phone Number *</label>
                            <input type="tel" id="phone" name="phone" placeholder="+1 234 567 8900" required>
                        </div>
                        <div class="form-group">
                            <label for="country">Preferred Country</label>
                            <select id="country" name="country">
                                <option value="">Select Country</option>
                                <?php
                                $countries = ["Finland","Canada","Sweden","United Kingdom","Denmark","Australia"];
                                foreach($countries as $c): ?>
                                <option value="<?php echo $c; ?>"><?php echo $c; ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="service">Service Required</label>
                        <select id="service" name="service">
                            <option value="">Select Service</option>
                            <option>Proficiency Test Preparation</option>
                            <option>University Admission</option>
                            <option>Visa Processing</option>
                            <option>English Language Course</option>
                            <option>Career Counseling</option>
                            <option>Pre-Departure Briefing</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="message">Your Message *</label>
                        <textarea id="message" name="message" rows="4" placeholder="Tell us about your study abroad goals..." required></textarea>
                    </div>
                    <button type="submit" name="contact_submit" class="btn-primary btn-block">
                        <i class="fas fa-paper-plane"></i> Send Message & Get Free Consultation
                    </button>
                </form>
            </div>
        </div>
    </div>
</section>

<!-- ===== FOOTER ===== -->
<footer class="footer">
    <div class="footer-top">
        <div class="container footer-grid">
            <div class="footer-col footer-brand">
                <img src="images/logo (2).jpg" alt="Academix Pro" class="footer-logo">
                <h3>Academix Pro</h3>
                <p>Your trusted gateway to world-class overseas education. Proficiency support, admissions, and 96.5% visa success — all under one roof.</p>
                <div class="footer-socials">
                    <a href="#" aria-label="Facebook"><i class="fab fa-facebook-f"></i></a>
                    <a href="https://wa.me/8801612594546" target="_blank" aria-label="WhatsApp"><i class="fab fa-whatsapp"></i></a>
                </div>
            </div>
            <div class="footer-col">
                <h4>Quick Links</h4>
                <ul>
                    <li><a href="#home"><i class="fas fa-chevron-right"></i> Home</a></li>
                    <li><a href="#services"><i class="fas fa-chevron-right"></i> Services</a></li>
                    <li><a href="#destinations"><i class="fas fa-chevron-right"></i> Destinations</a></li>
                    <li><a href="#about"><i class="fas fa-chevron-right"></i> About Us</a></li>
                    <li><a href="#team"><i class="fas fa-chevron-right"></i> Our Team</a></li>
                    <li><a href="#contact"><i class="fas fa-chevron-right"></i> Contact</a></li>
                </ul>
            </div>
            <div class="footer-col">
                <h4>Our Services</h4>
                <ul>
                    <li><a href="#services"><i class="fas fa-chevron-right"></i> IELTS / TOEFL Coaching</a></li>
                    <li><a href="#services"><i class="fas fa-chevron-right"></i> University Admission</a></li>
                    <li><a href="#services"><i class="fas fa-chevron-right"></i> Visa Processing</a></li>
                    <li><a href="#services"><i class="fas fa-chevron-right"></i> English Language Courses</a></li>
                    <li><a href="#services"><i class="fas fa-chevron-right"></i> Career Counseling</a></li>
                    <li><a href="#services"><i class="fas fa-chevron-right"></i> Pre-Departure Briefing</a></li>
                </ul>
            </div>
            <div class="footer-col">
                <h4>Contact Info</h4>
                <ul class="footer-contact">
                    <li><i class="fas fa-map-marker-alt"></i> 152/2/A Green Road Panthapath, Dhaka 1205</li>
                    <li><i class="fas fa-phone"></i> <a href="tel:+8801612594546">01612594546</a></li>
                    <li><i class="fas fa-phone"></i> <a href="tel:+8801701436662">01701436662</a></li>
                    <li><i class="fas fa-envelope"></i> <a href="mailto:info@academixprobd.com">info@academixprobd.com</a></li>
                    <li><i class="fas fa-clock"></i> Sat–Thu: 9AM – 7PM | Fri: Closed</li>
                </ul>
                <div class="footer-newsletter">
                    <h5>Newsletter</h5>
                    <form class="newsletter-form">
                        <input type="email" placeholder="Enter your email">
                        <button type="submit"><i class="fas fa-paper-plane"></i></button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <div class="footer-bottom">
        <div class="container footer-bottom-inner">
            <p>&copy; <?php echo date('Y'); ?> <strong>Academix Pro</strong>. All Rights Reserved.</p>
            <p>Designed with <i class="fas fa-heart" style="color:#e63946"></i> for aspiring global scholars</p>
        </div>
    </div>
</footer>

<!-- ===== BACK TO TOP ===== -->
<button class="back-to-top" id="backToTop" aria-label="Back to top"><i class="fas fa-chevron-up"></i></button>

<!-- ===== WHATSAPP FLOAT ===== -->
<a href="https://wa.me/8801612594546" class="whatsapp-float" target="_blank" aria-label="WhatsApp">
    <i class="fab fa-whatsapp"></i>
    <span>Chat on WhatsApp</span>
</a>

<script src="js/main.js"></script>
</body>
</html>
